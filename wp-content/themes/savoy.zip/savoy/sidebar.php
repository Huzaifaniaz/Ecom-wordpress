<aside class="nm-sidebar sidebar" role="complementary">	
	<?php do_action( 'before_sidebar' ); ?>
    
    <?php dynamic_sidebar( 'sidebar' ); ?>
</aside>